package br.com.teste.spring.appspbatch.repositories;

import br.com.teste.spring.appspbatch.model.Model;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface Rep001 extends JpaRepository<Model, Integer> {

    List<Model> findByBatchExecuteHistoryIdBatchIdOrderByCreateDateTimeAsc(String batchId, String pageable);


}
