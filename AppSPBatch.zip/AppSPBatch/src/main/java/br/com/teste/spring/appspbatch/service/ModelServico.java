package br.com.teste.spring.appspbatch.service;

import br.com.teste.spring.appspbatch.model.Model;
import br.com.teste.spring.appspbatch.repositories.Rep001;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;

import java.util.List;

public class ModelServico {

    Model model = new Model();
    private Rep001 rep001;

    @Autowired
    public ModelServico(Rep001 rep001){
        this.rep001 = rep001;
    }

    @PostConstruct
    public void findAllClient() {
        List<Model> memberEntitys = rep001.findAll();
        List<Model> memberEntitysWithOrderBy = rep001.findByBatchExecuteHistoryIdBatchIdOrderByCreateDateTimeAsc("1", String.valueOf(PageRequest.of(0, 2)));
        memberEntitysWithOrderBy.forEach(System.out::println);
    }
}
