package br.com.teste.spring.appspbatch.controller;

import br.com.teste.spring.appspbatch.model.Model;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import br.com.teste.spring.appspbatch.repositories.Rep001;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping(path = "/api", method = RequestMethod.POST)
public class Controller {

    @Autowired
    Rep001 repositorios;

    @PostMapping(path = "/post")
    public ResponseEntity<Model> posting(@RequestBody Model model) {
        repositorios.save(model);
        return ResponseEntity.status(HttpStatus.CREATED).body(model);
    }

    @DeleteMapping(value = "/delete/{id}")
    public void apagar(@PathVariable Integer id) throws ResourceNotFoundException {
        repositorios.deleteById(id);
    }

    @GetMapping(value = "/locale/{id}")
    public Optional<Model> localiza(@PathVariable Integer id) throws ResourceNotFoundException{
        return Optional.ofNullable(repositorios.findById(id).orElseThrow(() -> new ResourceNotFoundException("Item Not Found")));
    }

    @GetMapping(value="/localeOrderBy/{id}")
    public List<Model> localeOrderBy(@PathVariable String id, String orderBy){
       return repositorios.findByBatchExecuteHistoryIdBatchIdOrderByCreateDateTimeAsc(id,orderBy);
    }

    @PutMapping(value = "/udate/{id}")
    public Model update(@PathVariable Integer id, @RequestBody Model modeloNovo) throws ResourceNotFoundException {
        return repositorios.findById(id).map(modelo -> {
                    modelo.setName(modeloNovo.getName());
                    modelo.setCity(modeloNovo.getCity());
                    modelo.setAddress(modeloNovo.getAddress());
                    modelo.setZipcode(modeloNovo.getZipcode());
                    return repositorios.save(modelo);
                })
                .orElseGet(() -> {
                    modeloNovo.setId(id);
                    return repositorios.save(modeloNovo);
                });
    }
    @PatchMapping(path="/path/{id}")
    public Model path(@PathVariable Integer id, @RequestBody Model itemModelNew) throws ResourceNotFoundException {
        return repositorios.findById(id).map(modelo -> {
                    modelo.setName(itemModelNew.getName());
                    modelo.setCity(itemModelNew.getCity());
                    return repositorios.save(modelo);
                })
                .orElseGet(() -> {
                    itemModelNew.setId(id);
                    return repositorios.save(itemModelNew);
                });
    }

}
