create table cadastro_vr(
 id INTEGER auto_increment not null primary key,
name varchar(255),
address varchar(255),
 city varchar(200),
 zipcode numeric
)